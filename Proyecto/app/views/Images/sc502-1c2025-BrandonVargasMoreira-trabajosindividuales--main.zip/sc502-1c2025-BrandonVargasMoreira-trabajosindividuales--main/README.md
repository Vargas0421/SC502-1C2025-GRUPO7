# sc502-3c2024-BrandonVargasMoreira-trabajosindividuales-
GITHUB para los trabajos individuales, 
