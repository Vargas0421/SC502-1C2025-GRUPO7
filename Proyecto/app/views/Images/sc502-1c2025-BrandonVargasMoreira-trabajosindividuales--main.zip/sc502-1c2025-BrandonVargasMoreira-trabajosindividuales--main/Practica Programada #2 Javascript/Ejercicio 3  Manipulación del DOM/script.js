document.getElementById("cambiarTexto").addEventListener("click", function() {
    document.getElementById("mensaje").innerHTML = "¡El texto ha cambiado de manera exitosa!";
});